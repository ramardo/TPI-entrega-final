const userController = {};
const bd = require("../database/models");
const bcrypt = require('bcrypt'); // Asegúrate de instalar bcrypt
userController.registrarUsuario = async (req, res) => {
    try {
        const { nombre, correo, contrasena } = req.body;

        // Hash de la contraseña
        const hashedPassword = await bcrypt.hash(contrasena, 10);

        // Crear el nuevo usuario
        await bd.Persona.create({
            nombre,
            correo,
            contrasena: hashedPassword,
            tipo_usuario_id: 1, // Define el tipo de usuario según tus requerimientos
            curso_id: null, // O asigna un curso si es necesario
            foto_perfil: null // O asigna una foto si es necesario
        });

        res.redirect('/interfaz_estudiantes');
    } catch (error) {
        console.error("Error al registrar el usuario:", error);
        res.status(500).send("Error al registrar el usuario");
    }
};
