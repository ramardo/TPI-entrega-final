const mainController = {};
const bd = require("../database/models");
const bcrypt = require('bcrypt'); // Asegúrate de instalar bcrypt

mainController.index = async (req, res) => {
  try {
    const cursos = await bd.Curso.findAll();
    res.render("index", { cursos }); // Pasar cursos como un objeto
  } catch (error) {
    console.error("Error al obtener cursos:", error);
    res.status(500).send("Error al cargar la página de inicio");
  }
};
mainController.sendNote = async (req, res) => {
  const { alumno_nombre } = req.body;
  const alumno = bd.Persona.findOne({
    where: {
    }
  });
  const nota = bd.Nota.findOne();

}
mainController.validar = async (req,res) => {
  const {nombre,curso,materias,nota,cuatrimestre,informe} = req.body;
  const usuario = await bd.Persona.findOne({where: { nombre: nombre, curso_id: curso}});
  const materia = await bd.Materia.findOne({where: { nombre_materia: materias}});
  await bd.Nota.create({
    persona_id: usuario.persona_id,
    materia_id: materia.materia_id,
    curso_id: curso,
    nota: nota,
    cuatrimestre: cuatrimestre,
    informe: informe
  });
  res.redirect("/Interfaz_del_alumnado");
}
mainController.notas = async (req, res) => {
  try {
    // Buscar el usuario logueado
    const usuarioSession = req.session.Persona
    console.log("ID: ", req.session.Persona.persona_id);
    const usuario = await bd.Persona.findOne({
      where: { persona_id: req.session.Persona.persona_id },
      include: [{
        model: bd.Curso,
        as: 'curso',
        attributes: ['nombre_curso'],
        include: [{
          model: bd.Materia,
          as: 'materias',
          include: [{
            model: bd.Nota,
            as: 'notas',
            where: { persona_id: req.session.Persona.persona_id },
            attributes: ['nota', 'persona_id', 'cuatrimestre', 'informe'],
            required: false
          }]
        }]
      }]
    });
    //console.log(req.session);
    // Renderizar la vista 'notas'
    return res.render("notas", { usuario });
  } catch (error) {
    console.error("Error al obtener el usuario con el curso:", error.message);
    res.status(500).send("Error en el servidor");
  }
};

mainController.registrarUsuario = async (req, res) => {
  try {
    const { nombre, correo, contrasena, curso } = req.body;
    const tipo_usuario_id = 1; // Asigna automáticamente tipo_usuario_id como 1

    // Hash de la contraseña
    const hashedPassword = await bcrypt.hash(contrasena, 10);

    // Crear el nuevo usuario
    await bd.Persona.create({
      nombre,
      correo,
      contrasena: hashedPassword,
      tipo_usuario_id, // Asegurando que el usuario sea creado con el tipo 1
      curso_id: curso, // O asigna un curso si es necesario
      foto_perfil: null // O asigna una foto si es necesario
    });

    res.redirect('/Inicio_de_sesion'); // Redirigir a la página de inicio de sesión
  } catch (error) {
    console.error("Error al registrar el usuario:", error);
    res.status(500).send("Error al registrar el usuario");
  }
};

mainController.login = async (req, res) => {
  try {
    const { nombre, contrasena } = req.body;
    const usuario = await bd.Persona.findOne({ where: { nombre } });

    if (!usuario) {
      return res.send("usuario no encontrado");
    }

    //console.log('Tipo de usuario al iniciar sesión:', usuario.tipo_usuario_id); // Verificar el valor 
    const encontrado = bcrypt.compareSync(contrasena, usuario.contrasena);
    if (!encontrado) {
      return res.send("Contraseña incorrecta");
    }
    //console.log(usuario)
    switch (usuario.tipo_usuario_id) {
      case 1:
        req.session.Persona = usuario;
        return res.redirect("/interfaz_estudiantes");
      case 3:
        return res.redirect("/Interfaz_del_alumnado");
      default:
        return res.send("Tipo de usuario no encontrado");
    }
  } catch (error) {
    console.error("Error al buscar al usuario:", error);
    res.status(500).send("Error al buscar al usuario");
  }
};
// funcion para manejar la insercion de notas
// mainController.guardarNota = async (req, res) => {
//   const { alumno_id, materia_id, curso_id, nota, tipo_nota_id } = req.body;

//   try {
//     const resultado = await this.guardarNota(alumno_id, materia_id, curso_id, nota, tipo_nota_id);
//     if (resultado.success) {
//       res.render('guardado', { message: resultado.message });
//     } else {
//       res.status(500).json({ error: resultado.error });
//     }

//   } catch (error) {
//     res.status(500).json({ error: 'error al guardar la nota' })
//   }


// };



mainController.Incio_de_sesion = (req, res) => {
  res.render("Inicio_de_sesion");
};

mainController.Interfaz_estudiantes = (req, res) => {
  res.render("interfaz_estudiantes");
};

mainController.planilla_de_notas = (req, res) => {
  res.render("planilla_de_notas");
};

mainController.interfaz_alumnado = (req, res) => {
  res.render("Interfaz_del_alumnado");
};

mainController.alumnado_cursos = async (req, res) => {
  const alumnos = await bd.Persona.findAll();
  const materias = await bd.Materia.findAll();
  res.render("Interfaz_alumnado_cursos", { materias,alumnos });
};

mainController.alumnado_alumnos = (req, res) => {
  res.render("Interfaz_alumnado_alumnos");
};

module.exports = mainController;
