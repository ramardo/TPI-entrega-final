// funcion para guardar una nota en la base de datos
async function guardarNota(alumno_id, materia_id, curso_id, nota, tipo_nota_id) {
  try{
    await db.query(
      'INSERT INTO Nota (alumno_id, materia_id, curso_id, nota, tipo_nota_id) VALUES (?,?,?,?,?)',
      [alumno_id, materia_id, curso_id, nota, tipo_nota_id]
    );
    return { succes: true, message: ' Nota guardada con exito' };
  } catch (error) {
    console.error('error al guardar la nota:', error);
    return { succes: false, error: 'hubo un problema al guardar la nota'};
  }
}
Module.exports = {
  guardarNota
};