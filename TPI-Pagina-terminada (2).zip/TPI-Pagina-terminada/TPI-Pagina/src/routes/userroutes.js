const express = require("express")
const mainController = require("../controllers/maincontroller")
const router = express.Router()
router.get("/inicio_de_sesion", mainController.Incio_de_sesion)
module.exports = router;