const express = require('express');
const path = require('path');
const app = express();
const port = 4000;
const session = require('express-session');

app.use(session({
  secret: 'elsecreto',
  resave: false,
  saveUninitialized: true
}))
// db.js
const mysql = require('mysql');
const connection = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: '', // Cambia esto según tu configuración
  database: 'TecnoVision'
});

connection.connect((err) => {
  if (err) {
    console.error('Error al conectar con la base de datos:', err);
    return;
  }
  console.log('Conexión a la base de datos establecida');
});

module.exports = connection;


// Configuramos el motor de plantillas EJS
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Servimos los archivos estáticos (CSS, imágenes, etc.)
app.use(express.static(path.join(__dirname, '../Public'))); // Asegúrate de que esta ruta sea correcta

app.use(express.json());
// Middleware para parsear datos de formularios (application/x-www-form-urlencoded)
app.use(express.urlencoded({ extended: true }));

// Ruta raíz que renderiza la vista index.ejs
app.use("/", require("./routes/mainroutes.js"))
app.use("/alumno", require("./routes/userroutes.js"))

app.listen(port, () => {
  console.log(`Servidor escuchando en el puerto ${port}`);
});


app.post("/validar3", function(req, res) {
  const datos = req.body;
  console.log(datos)
  let nom = datos.Nombre
  let cur = datos.curso
  let materia = datos.materias
  let nota = datos.nota
  let cuatrimestre = datos.Cuatrimestre
  let informe = datos.Informe

  let regk = "INSERT INTO `nota` (`persona_id`, `curso_id`,  `materia_id`, `nota`,`cuatrimestre`, `informe` ) VALUES('" + nom + "','" + cur + "','" + materia + "','" + nota + "', '" + cuatrimestre + "', '" + informe + "')";
  connection.query(regk, function(error) {
    if (error) {
      throw error;
    } else {
      console.log("bien");
      res.redirect("/Interfaz_del_alumnado");
    }
  })
})

